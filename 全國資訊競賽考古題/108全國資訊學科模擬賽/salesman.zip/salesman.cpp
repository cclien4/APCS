#include<bits/stdc++.h>
using namespace std;

int N, M;
int cmap[101][101];
int numSol = 0;
set<string> solutions;
string pathStr;
bool flag = false;

void dfs(int x, int y) {
	pathStr += to_string(cmap[x][y]);
	if(x == N-1 && y == M-1) {
		solutions.insert(pathStr);
		numSol++;
		if(solutions.size() != numSol) {
			flag = true;
		}
	} else {
		if(x + 1 < N) {
			dfs(x + 1, y);
			pathStr = pathStr.substr(0, pathStr.size() - 1);
			if(flag) return;
		}
		if(y + 1 < M) {
			dfs(x, y + 1);
			pathStr = pathStr.substr(0, pathStr.size() - 1);
			if(flag) return;
		}
	}
}

int main(void) {
	int T;
	cin >> T;
	while(T--) {
		numSol = 0;
		solutions.clear();
		pathStr = "";
		flag = false;
		memset(cmap, 0, sizeof(cmap));
		cin >> N >> M;
		for(int i = 0; i < N; i++) {
			for(int j = 0; j < M; j++) {
				cin >> cmap[i][j];
			}
		}
		dfs(0, 0);
		if(flag) {
			cout << "Yes" << endl;
		} else {
			cout << "No" << endl;
		}
	}
}