#include <iostream>
using namespace std;

int main() {
string s;
 while(cin >> s){
cout << "hello, "<< s << endl;
 }
 return 0;
}
