#include <iostream>
using namespace std;

int main(void)
{
    int n;
    cin>>n;   
    if(n<15)
       cout<<n+24-15<<endl;
    else
        cout<<n-15<<endl;
    
    return 0;
}
