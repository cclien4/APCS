#include <bits/stdc++.h>
#define debug(x) cout<<#x<<" is "<<x<<endl;
using namespace std;
int n, m, arr[21][1000001], ans[21]={0}, memk[21]={0};
vector<int> vec(n), ch;

void dfs(int k)
{
	int tmp=0, flag=0;
		do
		{
			tmp=0; flag=0;
			for(int i=0;i<k;i++)
			{
				memk[vec[i]]=1;
			}
		for(int j=0;j<m;j++)
		{
			flag=0;
			for(int i=0;i<n;i++)
			{
				if(memk[i]==1)
				{
					if(arr[i][j]==0)
					{
						flag=1;
					}
				}
			}
			if(flag==0)
			{
				tmp++;
			}
		}
		ans[k]=max(tmp,ans[k]);
		
		for(int i=0;i<k;i++)
			{
				memk[vec[i]]=0;
			}
	
		reverse(vec.begin()+k,vec.end());
		}while(next_permutation(vec.begin(),vec.end()));
		


}

int main(void)
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	string tmp;
	cin>>n>>m;
	
	for(int i=0;i<n;i++)
	{
		cin>>tmp;
		for(int j=0;j<m;j++)
		{
			if(tmp[j]=='1')
			{
				arr[i][j]=0;
			}
			if(tmp[j]=='0')
			{
				arr[i][j]=1;
			}
		}
	}

	for(int i=1;i<=n;i++)
	{
		vec.clear();
		for(int j=0;j<n;j++)
		{
			vec.push_back(j);
		}
		dfs(i);
	}
	
	for(int i=1;i<=n;i++)
	{
		cout<<ans[i]<<endl;
	}
	
	return 0;
}
