#include<bits/stdc++.h>
using namespace std;

int HashValue = 01234567;
void AddAnswer(string s) {
        int n = s.length();
        for (int i = 0; i < n; ++i)
            HashValue = (HashValue * 131ll + s[i]) % 1000000123;
}
void PrintAnswer() {
        printf("%d\n", HashValue);
}

struct node{
	node* prev;
	string name;
	vector<string> next_names;
	vector<node*> next; 
};

int main(void) {
	node ground;
	ground.prev = NULL;
	ground.name = "ground";

	node *current = &ground;

	int N;
	scanf("%d", &N);
	while(N--) {
		string cmd;
		do{gets(cmd);}while(cmd == "" || cmd == "\n");
		if(cmd.substr(0, 3) == "dig") {
			string name = cmd.substr(4);
			bool exists = false;
			for (int i = 0; i < (current->next).size(); i++) {
				if(current->next[i]->name == name) {
					exists = true;
					break;
				}
			}
			if(exists) AddAnswer("'"+name+"' exist!\n");
			else {
				node* n = new node;
				n->prev = current;
				n->name = name;
				current->next.push_back(n);
				current->next_names.push_back(name);
			}
		}
		if(cmd.substr(0, 8) == "collapse") {
			string name = cmd.substr(9);
			bool exists = false;
			int target;
			for (int i = 0; i < current->next.size(); i++) {
				if(current->next[i]->name == name) {
					exists = true;
					target = i;
					break;
				}
			}
			if(!exists) AddAnswer("'"+name+"' not exist!\n");
			else {
				int i;
				for(i = 0; i < current->next_names.size(); i++) {
					if(current->next_names[i] == name) break;
				}
				current->next_names.erase(current->next_names.begin() + i);
				current->next.erase(current->next.begin() + target);
			}
		}
		if(cmd.substr(0, 5) == "go to") {
			string name = cmd.substr(6);
			bool exists = false;
			int target;
			for (int i = 0; i < current->next.size(); i++) {
				if(current->next[i]->name == name) {
					exists = true;
					target = i;
					break;
				}
			}
			if(!exists) AddAnswer("'"+name+"' not exist!\n");
			else current = current->next[target];
		}
		if(cmd == "go back") {
			if (current->prev == NULL) AddAnswer("You are on the ground!\n");
			else current = current->prev;
		}
		if(cmd == "where am I") {
			int count = 0;
			string output = "";
			node* temp = current;
			while(temp != NULL && count < 100) {
				if(output == "") {
					output = temp->name;
				} else {
					output = temp->name + " -> " + output;
				}
				temp = temp->prev;
				count++;
			}
			AddAnswer(output + "\n");
		}
		if(cmd == "where can I go") {
			sort(current->next_names.begin(), current->next_names.end());
			for(int i = 0; i < min((int)current->next_names.size(), 100); i++) {
				if(i == min((int)current->next_names.size(), 100) - 1) AddAnswer(current->next_names[i]);
				else AddAnswer(current->next_names[i]+" ");
			}
			if (current->next_names.size() > 100) AddAnswer("...");
			AddAnswer("\n");

		}
		/*cout << "DB" << current->name<<endl;
		cout << "DB";
		for(int i = 0; i < current->next.size(); i++) {
			cout << current->next[i]->name << " ";
		}cout << endl;*/
	}
	PrintAnswer();
}
