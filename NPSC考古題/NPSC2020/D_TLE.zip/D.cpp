#include<bits/stdc++.h>
using namespace std;

int bitcount(unsigned int n)
{
   int count = 0;
   while (n)
   {
      count++;
      n &= (n - 1) ;
   }
   return count;
}

bool bitat(int max, unsigned int n, int i) {
	int in = max - i - 1;
	return (n >> in) & 1;
}

unsigned int opp (int dig, unsigned int n) {
	return (~n) & ((1 << dig) - 1);
}

int main(void) {
	ios::sync_with_stdio(false);
	cin.tie(0);
	
	int N;
	while(cin >> N) {
		vector<vector<int> > numbers;
		for(int i = 0;i<2*N; i++) {
			vector<int> temp;
			for(int j = 0; j < 2*N; j++) {
				int a; cin >> a;
				temp.push_back(a);
			}
			numbers.push_back(temp);
		}

		unsigned int ind = pow(2, N) - 1;
		set<unsigned int> used; 
		long long ma = 0;
 
		while(ind < (int)(pow(2, N*2)-1)) {
			used.insert(ind);
			used.insert(opp(N*2,ind));
			long long sum = 0;
			for (int i = 0; i < 2 * N; i++) {
				if(bitat(2 * N, ind, i)) {
					for(int j = 0; j < 2 * N; j++) {
						if(!bitat(2 * N, ind, j)) sum += numbers[i][j];
					}
				}
			}
			ma = max(ma, sum);

			do {
				ind++;
			} while(bitcount(ind) != N || (ind < (int)(pow(2, N*2)-1) && used.find(ind)!=used.end()));
		}
		cout << ma << endl;
	}
}
